
# coding: utf-8

# In[1]:

# Define data and target



# In[2]:


# def setup_input():
#     df_name = 'fd.csv' # 'titanic.csv'
#     algo = 'RF' # LR NB SV
    
#     if(df_name == 'titanic.csv'):
#         df_name =  'df.csv'
#         target ='Survived'        
#         columns_to_drop = ['PassengerId','Ticket','Name','Cabin']
#         columns_to_convert = ['Pclass','Age','SibSp','Parch']    
    
#     elif(df_name == 'fd.csv'):           
#         target ='fd_taken'        
#         columns_to_drop = []
#         columns_to_convert = []
#     validation_set_name = 'validation_set.csv'      
#     df_processed_final = 'df_processed_final.csv'   
        
#     return df_name,target,validation_set_name,columns_to_drop,columns_to_convert,df_processed_final,algo 


# In[3]:


# setup_input()


# In[ ]:


def setup_input_new(df_name,algo):    
    if(df_name == 'df.csv'):                    
        columns_to_drop = ['PassengerId','Ticket','Name','Cabin']
        columns_to_convert = ['Pclass','Age','SibSp','Parch']    
    elif(df_name == 'fd.csv'):  
        columns_to_drop = []
        columns_to_convert = []
    validation_set_name = 'validation_set.csv'      
    df_processed_final = 'df_processed_final.csv'   
        
    return validation_set_name,columns_to_drop,columns_to_convert,df_processed_final

